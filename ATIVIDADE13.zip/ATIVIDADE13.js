
function calculoArea() {
    function Retangulo(x, y) {
        this.x = x;
        this.y = y;
        var resultado;
 
        this.calculo = function () {
            resultado = this.x * this.y;
            return resultado;
        }
    }
 
    var base = prompt("Digite a base do Retângulo: ");
    var altura = prompt("Digite a altura do Retângulo: ");
    varcalculoArea = new Retangulo(base, altura);
    alert("A área do retangulo é: " + varcalculoArea.calculo());
}
function ExibirDados() {
    function Conta() {
        var nome_correntista;
        var banco;
        var numero_conta;
        var saldo;
        this.setNome_correntista = function (value) {
            this.nome_correntista = value;
        }
        this.getNome_correntista = function () {
            return this.nome_correntista;
        }
        this.setBanco = function (value) {
            this.banco = value;
        }
        this.getBanco = function () {
            return this.banco;
        }
        this.setNum_conta = function (value) {
            this.num_conta = value;
        }
        this.getNum_conta = function () {
            return this.num_conta;
        }
        this.setSaldo = function (value) {
            this.saldo = value;
        }
        this.getSaldo = function () {
            return this.saldo;
        }
    }
 
    function Corrente() {
        Conta.call(this);
        var saldoEspecial;
 
        this.setSaldoEspecial = function (value) {
            saldoEspecial = value;
        }
 
        this.getSaldoEspecial = function () {
            return saldoEspecial;
        }
    }
 
    Corrente.prototype = Object.create(Conta.prototype);
 
    function Poupanca() {
        Conta.call(this);
 
        var juros, dataVenc;
 
        this.setJuros = function (value) {
            juros = value;
        }
 
        this.getJuros = function () {
            return juros;
        }
 
        this.setDataVencimento = function (value) {
            dataVenc = value;
        }
 
        this.getDataVencimento = function () {
            return dataVenc;
        }
    }
 
    Poupanca.prototype = Object.create(Conta.prototype);
 
    var objContaCorrente = new Corrente();
    objContaCorrente.setNome_correntista('Kamily');
    objContaCorrente.setBanco('Nubank');
    objContaCorrente.setNum_conta('123456');
    objContaCorrente.setSaldo(1502);
    objContaCorrente.setSaldoEspecial(10000);
 
    var objContaPoupanca = new Poupanca();
    objContaPoupanca.setNome_correntista('Nathaly');
    objContaPoupanca.setBanco('Santander');
    objContaPoupanca.setNum_conta('654321');
    objContaPoupanca.setSaldo(2603);
    objContaPoupanca.setJuros(0.05);
    objContaPoupanca.setDataVencimento('24/10/2023');
 
    alert("Nome: " +  objContaCorrente.getNome_correntista() + "\nBanco: " + objContaCorrente.getBanco() + "\nNúmero Conta: " + objContaCorrente.getNum_conta() + "\nSaldo: " + objContaCorrente.getSaldo() + "\nSaldo Especial: " + objContaCorrente.getSaldoEspecial());
    alert("Nome: " + objContaPoupanca.getNome_correntista() + "\nBanco: " + objContaPoupanca.getBanco() + "\nNúmero Conta: " + objContaPoupanca.getNum_conta() + "\nSaldo: " + objContaPoupanca.getSaldo() + "\nJuros: " + objContaPoupanca.getJuros() + "\nVencimento: " + objContaPoupanca.getDataVencimento());
}