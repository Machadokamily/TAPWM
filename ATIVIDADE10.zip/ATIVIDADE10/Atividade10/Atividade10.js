var A = parseFloat(prompt("Escreva um valor para A:"));
var B = parseFloat(prompt("Escreva um valor para B:"));
var C = parseFloat(prompt("Escreva um valor para C:"));


if (isNaN(A) || isNaN(B) || isNaN(C)) {
  alert("Insira números válidos para verificação.");
} else {
  
  if (A < B + C && B < A + C && C < A + B) {
    
    if (A === B && B === C) {
      alert("O triângulo formado por esses valores é equilátero.");
    } else if (A === B || A === C || B === C) {
      alert("O triângulo formado por esses valores é isósceles.");
    } else {
      alert("O triângulo formado por esses valores é escaleno.");
    }
  } else {
    alert("Esses valores não podem formar um triângulo.");
  }
}