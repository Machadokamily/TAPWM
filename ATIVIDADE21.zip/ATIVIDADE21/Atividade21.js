
   function criarObj() {
    event.preventDefault();
    const nome = document.getElementById("nome").value;
    const dataNasc = document.getElementById("dataNasc").value;
    const matriculado = document.querySelector('input[name="matriculado"]:checked').value;
    const endereco = document.getElementById("endereco").value;
    const hoje = new Date();
    const anoAtual = hoje.getFullYear();
    const dataNascFormatada = new Date(dataNasc);
    const anoNascimento = dataNascFormatada.getFullYear();
    if ((anoAtual - anoNascimento >= 7 && anoAtual - anoNascimento <= 17) && matriculado === "sim") {
      alert(`${nome} - ${dataNasc} - ${endereco} - está inscrito no torneio`);
    } else {
      alert(`${nome} - ${dataNasc} - ${endereco} - NÃO está inscrito porque não atende aos requisitos.`);
    }
   }