var num1, num2, num3, num4, maior = 0;

function SalvaNumMaior(){
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    const num3 = parseFloat(document.getElementById("num3").value);
    const num4 = parseFloat(document.getElementById("num4").value);

    MaiorNumero(num1, num2, num3, num4);
}

function SalvaNumCrescente(){
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    const num3 = parseFloat(document.getElementById("num3").value);
    const num4 = parseFloat(document.getElementById("num4").value);

    Crescente(num1, num2, num3, num4);
}

function MaiorNumero(num1, num2, num3, num4) {
    const maior = Math.max(num1, num2, num3, num4);
    alert("O número maior é: " + maior);
  }

function Crescente(num1, num2, num3, num4){
    const Oredenados = [num1, num2, num3, num4].sort((a, b) => a - b);
    alert("Ordem crescente: " + Oredenados.join(", "));
}