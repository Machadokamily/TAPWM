function Dividir() {
    let a = parseFloat(prompt("Informe o primeiro número:"));
    let b = parseFloat(prompt("Informe o segundo número:"));
    let resultado = a / b;
    if (isNaN(resultado)) {
      console.log("Divisão deu NaN");
    } else if (!isFinite(resultado)) {
        console.log("Divisão de Infinity");
    } else {
        console.log("Resultado da divisão: " + resultado);
    }
  }
  Dividir();