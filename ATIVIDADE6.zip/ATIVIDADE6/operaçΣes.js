var numero1 = parseFloat(prompt("Digite o primeiro número:"));
var numero2 = parseFloat(prompt("Digite o segundo número:"));

var soma = parseFloat(numero1) + parseFloat(numero2);

var subtracao = parseFloat(numero1) - parseFloat(numero2);

var produto = parseFloat(numero1) * parseFloat(numero2);

var divisao = parseFloat(numero1) / parseFloat(numero2);

var restoDivisao = numero1 % numero2;

 


alert("Soma: " + soma + '\n' + "Subtração: " + subtracao + 
'\n' + "Produto: " + produto + '\n' + "Divisão: " + divisao + 
'\n' + "Resto da Divisão: " + restoDivisao);