function Ordena() {
    let numeros = [];
    for (let i = 0; i < 5; i++) {
      let numero = prompt("Informe o número" );
      numeros.push(parseFloat(numero)); 
    }
    numeros.sort((a, b) => b - a);
    console.log("Números em ordem decrescente: " + numeros);
  }
  Ordena();