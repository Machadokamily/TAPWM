function Procura() {
    let texto = prompt("Informe um texto:");
    let textoMinusculo = texto.toLowerCase();
    let contador = 0;
    for (let i = 0; i < textoMinusculo.length; i++) {
      if (textoMinusculo[i] === 'a') {
        contador++;
      }
    }
    console.log( "Qntde de letras 'A' encontradas: " + contador);
  }
  Procura();